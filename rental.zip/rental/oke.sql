-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.28-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for rental
CREATE DATABASE IF NOT EXISTS `rental` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `rental`;

-- Dumping structure for table rental.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `nama_admin` varchar(50) NOT NULL,
  `jenkel_admin` varchar(20) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `level` varchar(30) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table rental.admin: ~3 rows (approximately)
INSERT INTO `admin` (`id_admin`, `nama_admin`, `jenkel_admin`, `username`, `password`, `level`) VALUES
	(1, 'Desi', 'Perempuan', 'desi', 'desi123', 'SUPER'),
	(2, 'Shara', 'Perempuan', 'shara', 'shara123', 'ADMIN'),
	(4, 'Zahra', 'Perempuan', 'zahra', 'zahra123', 'ADMIN');

-- Dumping structure for table rental.kalkulasi_km
CREATE TABLE IF NOT EXISTS `kalkulasi_km` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mobil` int(11) DEFAULT NULL,
  `id_order` int(11) DEFAULT NULL,
  `id_pelanggan` int(11) DEFAULT NULL,
  `km_awal` int(11) DEFAULT NULL,
  `km_akhir` int(11) DEFAULT NULL,
  `total_harga` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table rental.kalkulasi_km: ~0 rows (approximately)

-- Dumping structure for table rental.laporan
CREATE TABLE IF NOT EXISTS `laporan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pelanggan` varchar(255) NOT NULL,
  `mobil` varchar(255) NOT NULL,
  `tanggal_sewa` date NOT NULL,
  `pembayaran` int(11) NOT NULL DEFAULT 0,
  `tanggal_kembali` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table rental.laporan: ~0 rows (approximately)

-- Dumping structure for table rental.mobil
CREATE TABLE IF NOT EXISTS `mobil` (
  `id_mobil` int(11) NOT NULL AUTO_INCREMENT,
  `no_polisi` varchar(12) NOT NULL,
  `merk` varchar(90) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `tahun` varchar(10) NOT NULL,
  `s_mobil` varchar(20) NOT NULL,
  `odometer` int(11) DEFAULT NULL,
  `harga_pokok` double NOT NULL,
  `harga_km` double DEFAULT NULL,
  PRIMARY KEY (`id_mobil`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table rental.mobil: ~5 rows (approximately)
INSERT INTO `mobil` (`id_mobil`, `no_polisi`, `merk`, `foto`, `tahun`, `s_mobil`, `odometer`, `harga_pokok`, `harga_km`) VALUES
	(1, 'BK 1224 XX', 'Toyota Avanza Veloz', 'gambar1.jpg', '2014', 'AKTIF', 447380, 150000, 5000),
	(3, 'BK 1111 AB', 'Suzuki Ertiga', 'gambar4.jpg', '2016', 'AKTIF', 123455, 300000, 7000),
	(4, 'BK 1010 XY', 'Fortuner', 'gambar3.jpg', '2018', 'AKTIF', 345690, 500000, 12000),
	(5, 'BK 1212 DR', 'Tesla Model 3', 'gambar2.jpg', '2021', 'AKTIF', 456789, 450000, 10000),
	(12, '12 Mei', '12', '20231030_222609.jpg', '22', 'AKTIF', 123456, 1209, 2727);

-- Dumping structure for table rental.pelanggan
CREATE TABLE IF NOT EXISTS `pelanggan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `ktp` varchar(50) DEFAULT NULL,
  `jk` varchar(50) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `telp` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table rental.pelanggan: ~4 rows (approximately)
INSERT INTO `pelanggan` (`id`, `nama`, `ktp`, `jk`, `alamat`, `telp`) VALUES
	(4, 'Hanbin', '33087362811190', 'Laki - Laki', 'Green Mulia Saphire No.56 Block A, Ajibarang', NULL),
	(5, 'Jennie', '33087253718352', 'Perempuan', 'Pandansari Rt11/Rw10, Ajibarang', NULL),
	(6, 'Krystal', '338536292000123', 'Perempuan', 'Purbalingga', NULL),
	(7, 'Roynaldi', '3303171205010002', 'Laki - Laki', 'Sirandu', '081234567890');

-- Dumping structure for table rental.sewa
CREATE TABLE IF NOT EXISTS `sewa` (
  `id_sewa` int(11) NOT NULL AUTO_INCREMENT,
  `id_mobil` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `id_pelanggan` varchar(90) NOT NULL,
  `tgl_sewa` date NOT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `uang_muka` double DEFAULT NULL,
  `uang_muka_dibayar` int(11) DEFAULT NULL,
  `km_awal` int(11) NOT NULL DEFAULT 0,
  `km_akhir` int(11) DEFAULT 0,
  `harga_akhir` double DEFAULT 0,
  `lama_sewa` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_sewa`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table rental.sewa: ~5 rows (approximately)
INSERT INTO `sewa` (`id_sewa`, `id_mobil`, `id_admin`, `id_pelanggan`, `tgl_sewa`, `tgl_kembali`, `uang_muka`, `uang_muka_dibayar`, `km_awal`, `km_akhir`, `harga_akhir`, `lama_sewa`) VALUES
	(28, 3, 1, '7', '2023-05-12', '2023-05-16', 0, 1200000, 123455, 0, 0, 4);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
